# ESP32 MultiNet Voice Demo

Offline voice command recognition on the **Seeed Xiao ESP32-S3 Sense** with the **Round Display** expansion. Say the wake word **Jarvis**, then speak a command — the recognized phrase appears as text on the 240×240 round LCD.

Built with **ESP-IDF 5.5.x**, [ESP-SR](https://github.com/espressif/esp-sr) (WakeNet + MultiNet6), and LVGL.

## Hardware required

| Item | Notes |
| --- | --- |
| [Seeed Xiao ESP32-S3 Sense](https://wiki.seeedstudio.com/xiao_esp32s3_getting_started/) | 8 MB flash, 8 MB PSRAM, onboard PDM microphone |
| [Seeed Round Display for XIAO](https://wiki.seeedstudio.com/seeedstudio_round_display_usage/) | GC9A01 240×240 SPI display |
| USB-C cable | Used for power, flash, and serial monitor |

**Before powering on:**

1. Stack the **Sense** expansion board on the Xiao (provides the microphone).
2. Stack the **Round Display** on top.
3. Set the Round Display **power switch to ON** (backlight and power path).

## Software requirements

- **ESP-IDF v5.5.x** (tested with 5.5.4)
- **VS Code or Cursor** with the [Espressif ESP-IDF extension](https://marketplace.visualstudio.com/items?itemName=espressif.esp-idf)
- **Windows:** [ESP-IDF Windows setup guide](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/get-started/windows-setup.html) or use the extension’s guided installer

---

## ESP-IDF and IDE setup

### Step 1 — Install ESP-IDF

Pick **one** of these paths:

**Option A — ESP-IDF Tools Installer (Windows, recommended for beginners)**

1. Follow the [Windows ESP-IDF installation guide](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/get-started/windows-setup.html).
2. Install **ESP-IDF v5.5.x** and the **esp32s3** target when prompted.
3. Note the install path (e.g. `C:\esp\v5.5.4\esp-idf`).

**Option B — Configure via VS Code / Cursor extension**

1. Install the **ESP-IDF** extension (`espressif.esp-idf`).
2. Open the Command Palette (`Ctrl+Shift+P`).
3. Run **`ESP-IDF: Configure ESP-IDF extension`**.
4. Choose **Express** or **Advanced** install.
5. Select **ESP-IDF v5.5.x** and target **esp32s3**.

Extension install guide: [vscode-esp-idf-extension tutorial](https://github.com/espressif/vscode-esp-idf-extension/blob/master/docs/tutorial/install.md)

### Step 2 — Install the ESP-IDF extension

In VS Code or Cursor:

1. Open **Extensions** (`Ctrl+Shift+X`).
2. Search for **`Espressif IDF`**.
3. Install **ESP-IDF** by Espressif Systems.

If prompted, also install the recommended extensions from `.vscode/extensions.json`.

### Step 3 — Open this project

```text
File → Open Folder → esp32-multinet-demo
```

### Step 4 — Point the extension at your ESP-IDF install

1. Command Palette → **`ESP-IDF: Select ESP-IDF Path`** (or **`ESP-IDF: Configure ESP-IDF extension`**).
2. Set **`idf.currentSetup`** to your ESP-IDF directory, for example:
   - `C:\esp\v5.5.4\esp-idf`
3. Confirm the chip target is **esp32s3**:
   - Command Palette → **`ESP-IDF: Set Espressif Device Target`** → **esp32s3**

Workspace settings in [`.vscode/settings.json`](.vscode/settings.json) already set `IDF_TARGET` to `esp32s3`. Update `idf.currentSetup` to match **your** machine.

### Step 5 — Select the serial port

1. Plug in the Xiao via USB.
2. In the ESP-IDF status bar, click the **port** item and choose your board (e.g. `COM4`), or leave it on **`detect`**.

**Important:** Logs use **USB Serial/JTAG**, not the external UART pins. GPIO 43/44 are used by the round display. This is configured in [`sdkconfig.defaults`](sdkconfig.defaults).

---

## Build the project

### From the IDE (easiest)

1. Click **Build** (hammer icon) in the ESP-IDF status bar, or
2. Command Palette → **`ESP-IDF: Build your project`**

Or use **Terminal → Run Task → ESP-IDF: Build**.

### From the terminal (Windows)

```powershell
.\scripts\build.ps1
```

Or manually:

```powershell
. C:\esp\v5.5.4\esp-idf\export.ps1   # adjust to your ESP-IDF path
$env:PYTHONIOENCODING = "utf-8"      # required on Windows for esp-sr model packaging
cd path\to\esp32-multinet-demo
idf.py set-target esp32s3
idf.py build
```

### First build notes

- Downloads managed components (`esp-sr`, LVGL, GC9A01 driver) via the [ESP Component Manager](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/tools/idf-component-manager.html).
- Packages ~5 MB speech models into `build/srmodels/srmodels.bin` — the first build can take several minutes.
- Board defaults come from [`sdkconfig.defaults`](sdkconfig.defaults). If configuration looks wrong, delete `sdkconfig` and rebuild.

You do **not** need `idf.py menuconfig` for a standard run.

---

## Flash and monitor

### From the IDE

1. Select the correct **COM port** in the status bar.
2. Click **Flash** (lightning icon).
3. Click **Monitor** (plug icon), or use **`ESP-IDF: Monitor your device`**.

Or **Terminal → Run Task → ESP-IDF: Build, Flash and Monitor**.

### From the terminal

```powershell
.\scripts\flash-monitor.ps1 -Port COM4   # replace COM4 with your port
```

Or:

```powershell
. C:\esp\v5.5.4\esp-idf\export.ps1
$env:PYTHONIOENCODING = "utf-8"
idf.py -p COM4 flash monitor
```

`idf.py flash` writes **three** images: bootloader, application, and the **srmodels** partition (required for speech recognition).

Press **`Ctrl+]`** to exit the serial monitor.

---

## How to use the demo

```
Boot          →  Display shows: Say "Jarvis"
Say "Jarvis"  →  Display shows: Jarvis!  then  Listening...
Say a command →  Display shows the recognized phrase
Silence       →  Returns to: Say "Jarvis"
```

### Voice commands

| Step | Say | Display |
| --- | --- | --- |
| Wake word | **Jarvis** | `Jarvis!` → `Listening...` |
| Command | See list below | Matched phrase |

**Built-in commands** (defined in [`main/speech_recognition.c`](main/speech_recognition.c)):

| # | Phrase to speak |
| --- | --- |
| 1 | turn on the light |
| 2 | turn off the light |
| 3 | say hello |
| 4 | what is the weather |
| 5 | what is the time |

Speak clearly, about 30 cm from the microphone. The USB serial log shows wake and command events for debugging.

### Customizing commands

Edit `register_speech_commands()` in [`main/speech_recognition.c`](main/speech_recognition.c), then rebuild and reflash.

---

## Troubleshooting

| Problem | What to try |
| --- | --- |
| Blank display | Round Display switch **ON**; reflash firmware |
| Backwards / mirrored text | Reflash the latest firmware ([`main/round_display.c`](main/round_display.c) sets correct orientation) |
| Build fails with `UnicodeEncodeError` on Windows | Run `.\scripts\build.ps1` or set `$env:PYTHONIOENCODING = "utf-8"` before `idf.py build` |
| No serial output | Use the **USB** port, not external UART pins |
| Wake word not detected | Say **Jarvis** clearly; check monitor for `Wake word detected` |
| Flash size errors | Board needs **8 MB** flash (set in `sdkconfig.defaults`) |
| Wrong COM port | Command Palette → **`ESP-IDF: Select port to use`** |
| Extension can’t find ESP-IDF | Command Palette → **`ESP-IDF: Select ESP-IDF Path`** |

---

## Project layout

```text
main/
  main.c                 Application entry
  board_audio.c          PDM microphone (GPIO 41/42)
  speech_recognition.c   WakeNet + MultiNet pipeline
  display_ui.c           Round display text UI
  round_display.c        GC9A01 + LVGL init
  idf_component.yml      Managed dependencies
sdkconfig.defaults       Board and SR model defaults
partitions.csv           App + speech model partitions
dependencies.lock        Pinned component versions (keep in repo)
scripts/
  build.ps1              Windows build helper
  flash-monitor.ps1      Windows flash + monitor helper
```

---

## Reference links

- [ESP-IDF Programming Guide (ESP32-S3)](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/index.html)
- [ESP-IDF Get Started](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/get-started/index.html)
- [ESP-SR / MultiNet documentation](https://docs.espressif.com/projects/esp-sr/en/latest/esp32s3/speech_command_recognition/README.html)
- [ESP-IDF VS Code extension docs](https://github.com/espressif/vscode-esp-idf-extension/blob/master/docs/tutorial/install.md)
- [Xiao ESP32-S3 Sense microphone](https://wiki.seeedstudio.com/xiao_esp32s3_sense_mic/)
- [Round Display hardware usage](https://wiki.seeedstudio.com/seeedstudio_round_display_usage/)

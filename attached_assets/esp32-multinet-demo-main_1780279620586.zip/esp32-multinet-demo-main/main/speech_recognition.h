#pragma once

#include "esp_err.h"

esp_err_t speech_recognition_start(void);

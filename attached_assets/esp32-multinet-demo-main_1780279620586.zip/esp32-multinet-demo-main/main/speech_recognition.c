#include "speech_recognition.h"

#include <stdlib.h>
#include <string.h>

#include "board_audio.h"
#include "display_ui.h"
#include "esp_afe_sr_iface.h"
#include "esp_afe_sr_models.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_mn_iface.h"
#include "esp_mn_models.h"
#include "esp_mn_speech_commands.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "model_path.h"

static const char *TAG = "speech";

static const esp_afe_sr_iface_t *s_afe_handle = NULL;
static volatile int s_task_flag = 0;
static srmodel_list_t *s_models = NULL;

static void post_ui_event(display_ui_event_type_t type, const char *text)
{
    display_ui_event_t event = {
        .type = type,
    };
    if (text != NULL) {
        strlcpy(event.text, text, sizeof(event.text));
    }
    display_ui_post_event(&event);
}

static void register_speech_commands(esp_mn_iface_t *multinet, model_iface_data_t *model_data)
{
    esp_mn_commands_clear();
    esp_mn_commands_add(1, "turn on the light");
    esp_mn_commands_add(2, "turn off the light");
    esp_mn_commands_add(3, "say hello");
    esp_mn_commands_add(4, "what is the weather");
    esp_mn_commands_add(5, "what is the time");
    esp_mn_error_t *errors = esp_mn_commands_update();
    if (errors != NULL) {
        ESP_LOGW(TAG, "Some commands failed to update");
    }
    multinet->print_active_speech_commands(model_data);
}

static void detect_task(void *arg)
{
    esp_afe_sr_data_t *afe_data = (esp_afe_sr_data_t *)arg;
    int afe_chunksize = s_afe_handle->get_fetch_chunksize(afe_data);
    char *mn_name = esp_srmodel_filter(s_models, ESP_MN_PREFIX, ESP_MN_ENGLISH);
    ESP_LOGI(TAG, "MultiNet model: %s", mn_name);

    esp_mn_iface_t *multinet = esp_mn_handle_from_name(mn_name);
    model_iface_data_t *model_data = multinet->create(mn_name, 6000);
    int mu_chunksize = multinet->get_samp_chunksize(model_data);
    register_speech_commands(multinet, model_data);
    ESP_ERROR_CHECK(mu_chunksize == afe_chunksize ? ESP_OK : ESP_FAIL);

    int wakeup_flag = 0;
    ESP_LOGI(TAG, "Speech detection started");

    while (s_task_flag) {
        afe_fetch_result_t *res = s_afe_handle->fetch(afe_data);
        if (res == NULL || res->ret_value == ESP_FAIL) {
            ESP_LOGE(TAG, "AFE fetch error");
            break;
        }

        if (res->wakeup_state == WAKENET_DETECTED) {
            ESP_LOGI(TAG, "Wake word detected");
            multinet->clean(model_data);
            post_ui_event(DISPLAY_UI_EVENT_WAKE, NULL);
            post_ui_event(DISPLAY_UI_EVENT_LISTENING, NULL);
            wakeup_flag = 1;
        }

        if (wakeup_flag == 1) {
            esp_mn_state_t mn_state = multinet->detect(model_data, res->data);

            if (mn_state == ESP_MN_STATE_DETECTING) {
                continue;
            }

            if (mn_state == ESP_MN_STATE_DETECTED) {
                esp_mn_results_t *mn_result = multinet->get_results(model_data);
                for (int i = 0; i < mn_result->num; i++) {
                    ESP_LOGI(TAG, "Command: id=%d phrase=%d text=%s prob=%.2f",
                             mn_result->command_id[i], mn_result->phrase_id[i],
                             mn_result->string, mn_result->prob[i]);
                }
                if (mn_result->num > 0 && mn_result->string[0] != '\0') {
                    post_ui_event(DISPLAY_UI_EVENT_COMMAND, mn_result->string);
                }
            }

            if (mn_state == ESP_MN_STATE_TIMEOUT) {
                ESP_LOGI(TAG, "MultiNet timeout, waiting for wake word");
                s_afe_handle->enable_wakenet(afe_data);
                wakeup_flag = 0;
                post_ui_event(DISPLAY_UI_EVENT_IDLE, NULL);
            }
        }
    }

    if (model_data) {
        multinet->destroy(model_data);
    }
    vTaskDelete(NULL);
}

esp_err_t speech_recognition_start(void)
{
    s_models = esp_srmodel_init("model");
    ESP_RETURN_ON_FALSE(s_models != NULL, ESP_FAIL, TAG, "Failed to load SR models");

    ESP_RETURN_ON_ERROR(board_audio_init(), TAG, "Board audio init failed");

    afe_config_t *afe_config = afe_config_init("M", s_models, AFE_TYPE_SR, AFE_MODE_LOW_COST);
    ESP_RETURN_ON_FALSE(afe_config != NULL, ESP_FAIL, TAG, "AFE config init failed");

    s_afe_handle = esp_afe_handle_from_config(afe_config);
    esp_afe_sr_data_t *afe_data = s_afe_handle->create_from_config(afe_config);
    afe_config_free(afe_config);
    ESP_RETURN_ON_FALSE(afe_data != NULL, ESP_FAIL, TAG, "AFE create failed");

    static board_audio_feed_args_t feed_args;
    feed_args.afe_data = afe_data;
    feed_args.afe_handle = s_afe_handle;

    s_task_flag = 1;

    BaseType_t feed_created = xTaskCreatePinnedToCore(
        board_audio_feed_task, "feed", 8 * 1024, &feed_args, 5, NULL, 0);
    ESP_RETURN_ON_FALSE(feed_created == pdPASS, ESP_ERR_NO_MEM, TAG, "Feed task create failed");

    BaseType_t detect_created = xTaskCreatePinnedToCore(
        detect_task, "detect", 8 * 1024, afe_data, 5, NULL, 1);
    ESP_RETURN_ON_FALSE(detect_created == pdPASS, ESP_ERR_NO_MEM, TAG, "Detect task create failed");

    ESP_LOGI(TAG, "Speech recognition started");
    return ESP_OK;
}

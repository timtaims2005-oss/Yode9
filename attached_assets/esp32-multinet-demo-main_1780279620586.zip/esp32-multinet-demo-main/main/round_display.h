#pragma once

#include "esp_err.h"

esp_err_t round_display_init(void);

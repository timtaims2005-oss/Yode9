#include "board_audio.h"

#include <stdlib.h>

#include "driver/i2s_pdm.h"
#include "esp_check.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "board_audio";

#define PDM_CLK_GPIO GPIO_NUM_42
#define PDM_DIN_GPIO GPIO_NUM_41

static i2s_chan_handle_t s_rx_chan;

esp_err_t board_audio_init(void)
{
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    ESP_RETURN_ON_ERROR(i2s_new_channel(&chan_cfg, NULL, &s_rx_chan), TAG, "i2s_new_channel failed");

    i2s_pdm_rx_config_t pdm_rx_cfg = {
        .clk_cfg = I2S_PDM_RX_CLK_DEFAULT_CONFIG(BOARD_AUDIO_SAMPLE_RATE),
        .slot_cfg = I2S_PDM_RX_SLOT_PCM_FMT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
        .gpio_cfg = {
            .clk = PDM_CLK_GPIO,
            .din = PDM_DIN_GPIO,
            .invert_flags = {
                .clk_inv = false,
            },
        },
    };

    ESP_RETURN_ON_ERROR(i2s_channel_init_pdm_rx_mode(s_rx_chan, &pdm_rx_cfg), TAG, "PDM RX init failed");
    ESP_RETURN_ON_ERROR(i2s_channel_enable(s_rx_chan), TAG, "i2s enable failed");

    ESP_LOGI(TAG, "PDM mic initialized (clk=%d, din=%d, %d Hz)", PDM_CLK_GPIO, PDM_DIN_GPIO, BOARD_AUDIO_SAMPLE_RATE);
    return ESP_OK;
}

void board_audio_feed_task(void *arg)
{
    board_audio_feed_args_t *args = (board_audio_feed_args_t *)arg;
    esp_afe_sr_data_t *afe_data = args->afe_data;
    const esp_afe_sr_iface_t *afe_handle = args->afe_handle;

    int audio_chunksize = afe_handle->get_feed_chunksize(afe_data);
    int feed_channel = afe_handle->get_feed_channel_num(afe_data);
    size_t frame_bytes = (size_t)audio_chunksize * (size_t)feed_channel * sizeof(int16_t);
    int16_t *i2s_buff = heap_caps_malloc(frame_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (i2s_buff == NULL) {
        ESP_LOGE(TAG, "Failed to allocate feed buffer");
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "Feed task started (chunk=%d, channels=%d)", audio_chunksize, feed_channel);

    while (true) {
        size_t bytes_read = 0;
        esp_err_t err = i2s_channel_read(s_rx_chan, i2s_buff, frame_bytes, &bytes_read, portMAX_DELAY);
        if (err != ESP_OK || bytes_read != frame_bytes) {
            ESP_LOGW(TAG, "I2S read error: %s, read=%u", esp_err_to_name(err), (unsigned)bytes_read);
            continue;
        }
        afe_handle->feed(afe_data, i2s_buff);
    }
}

#include <stdio.h>

#include "display_ui.h"
#include "esp_log.h"
#include "speech_recognition.h"

static const char *TAG = "main";

void app_main(void)
{
    ESP_LOGI(TAG, "MultiNet voice demo starting");

    ESP_ERROR_CHECK(display_ui_init());
    ESP_ERROR_CHECK(speech_recognition_start());

    ESP_LOGI(TAG, "Ready — say \"Jarvis\" then a command");
}

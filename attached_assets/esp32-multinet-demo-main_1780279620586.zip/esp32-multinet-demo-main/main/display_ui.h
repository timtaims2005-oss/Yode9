#pragma once

#include "esp_err.h"

typedef enum {
    DISPLAY_UI_EVENT_IDLE = 0,
    DISPLAY_UI_EVENT_WAKE,
    DISPLAY_UI_EVENT_LISTENING,
    DISPLAY_UI_EVENT_COMMAND,
} display_ui_event_type_t;

typedef struct {
    display_ui_event_type_t type;
    char text[64];
} display_ui_event_t;

esp_err_t display_ui_init(void);

void display_ui_post_event(const display_ui_event_t *event);

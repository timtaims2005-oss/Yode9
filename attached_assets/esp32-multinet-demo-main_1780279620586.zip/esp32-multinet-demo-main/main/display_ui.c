#include "display_ui.h"

#include <string.h>

#include "esp_check.h"
#include "esp_log.h"
#include "esp_lvgl_port.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "lvgl.h"
#include "round_display.h"

static const char *TAG = "display_ui";

#define UI_QUEUE_LEN 8

static QueueHandle_t s_ui_queue;
static lv_obj_t *s_label;

static void ui_task(void *arg)
{
    display_ui_event_t event;

    while (true) {
        if (xQueueReceive(s_ui_queue, &event, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        if (lvgl_port_lock(0)) {
            switch (event.type) {
            case DISPLAY_UI_EVENT_IDLE:
                lv_label_set_text(s_label, "Say \"Jarvis\"");
                lv_obj_set_style_text_color(s_label, lv_color_hex(0xFFFFFF), 0);
                break;
            case DISPLAY_UI_EVENT_WAKE:
                lv_label_set_text(s_label, "Jarvis!");
                lv_obj_set_style_text_color(s_label, lv_color_hex(0x00FF88), 0);
                break;
            case DISPLAY_UI_EVENT_LISTENING:
                lv_label_set_text(s_label, "Listening...");
                lv_obj_set_style_text_color(s_label, lv_color_hex(0xFFCC00), 0);
                break;
            case DISPLAY_UI_EVENT_COMMAND:
                lv_label_set_text(s_label, event.text);
                lv_obj_set_style_text_color(s_label, lv_color_hex(0xFFFFFF), 0);
                break;
            default:
                break;
            }
            lvgl_port_unlock();
        }
    }
}

esp_err_t display_ui_init(void)
{
    ESP_RETURN_ON_ERROR(round_display_init(), TAG, "Round display init failed");

    s_ui_queue = xQueueCreate(UI_QUEUE_LEN, sizeof(display_ui_event_t));
    ESP_RETURN_ON_FALSE(s_ui_queue != NULL, ESP_ERR_NO_MEM, TAG, "UI queue create failed");

    if (lvgl_port_lock(0)) {
        lv_obj_t *scr = lv_scr_act();
        lv_obj_set_style_bg_color(scr, lv_color_hex(0x000000), 0);
        lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);

        s_label = lv_label_create(scr);
        lv_obj_set_width(s_label, 210);
        lv_label_set_long_mode(s_label, LV_LABEL_LONG_WRAP);
        lv_obj_set_style_text_align(s_label, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_style_text_font(s_label, &lv_font_montserrat_24, 0);
        lv_obj_set_style_text_color(s_label, lv_color_hex(0xFFFFFF), 0);
        lv_obj_align(s_label, LV_ALIGN_CENTER, 0, 0);
        lv_label_set_text(s_label, "Say \"Jarvis\"");
        lvgl_port_unlock();
    }

    BaseType_t created = xTaskCreatePinnedToCore(ui_task, "ui_task", 4096, NULL, 4, NULL, 0);
    ESP_RETURN_ON_FALSE(created == pdPASS, ESP_ERR_NO_MEM, TAG, "UI task create failed");

    ESP_LOGI(TAG, "Display UI initialized");
    return ESP_OK;
}

void display_ui_post_event(const display_ui_event_t *event)
{
    if (s_ui_queue == NULL || event == NULL) {
        return;
    }
    xQueueSend(s_ui_queue, event, 0);
}

#pragma once

#include "esp_err.h"
#include "esp_afe_sr_iface.h"

#define BOARD_AUDIO_SAMPLE_RATE 16000

typedef struct {
    esp_afe_sr_data_t *afe_data;
    const esp_afe_sr_iface_t *afe_handle;
} board_audio_feed_args_t;

esp_err_t board_audio_init(void);

void board_audio_feed_task(void *arg);

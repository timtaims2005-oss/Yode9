# Flash and monitor esp32-multinet-demo (Windows).
# Usage: .\scripts\flash-monitor.ps1 -Port COM4

param(
    [Parameter(Mandatory = $false)]
    [string]$Port = "detect"
)

$ErrorActionPreference = "Stop"

$env:PYTHONIOENCODING = "utf-8"

if (-not $env:IDF_PATH) {
    $commonPaths = @(
        "C:\esp\v5.5.4\esp-idf",
        "$env:USERPROFILE\esp\v5.5.4\esp-idf",
        "$env:USERPROFILE\esp\esp-idf"
    )

    foreach ($path in $commonPaths) {
        $exportScript = Join-Path $path "export.ps1"
        if (Test-Path $exportScript) {
            Write-Host "Sourcing ESP-IDF from $path"
            . $exportScript
            break
        }
    }
}

if (-not $env:IDF_PATH) {
    Write-Error @"
ESP-IDF environment not found.

Run . C:\path\to\esp-idf\export.ps1 first, or use an ESP-IDF terminal.
See README.md for setup instructions.
"@
}

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

Write-Host "Flashing to $Port (Ctrl+] to exit monitor)..."
idf.py -p $Port flash monitor

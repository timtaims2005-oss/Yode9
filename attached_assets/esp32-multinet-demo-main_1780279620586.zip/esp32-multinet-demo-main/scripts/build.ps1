# Build esp32-multinet-demo with ESP-IDF (Windows).
# Usage: .\scripts\build.ps1

$ErrorActionPreference = "Stop"

$env:PYTHONIOENCODING = "utf-8"

if (-not $env:IDF_PATH) {
    $commonPaths = @(
        "C:\esp\v5.5.4\esp-idf",
        "$env:USERPROFILE\esp\v5.5.4\esp-idf",
        "$env:USERPROFILE\esp\esp-idf"
    )

    foreach ($path in $commonPaths) {
        $exportScript = Join-Path $path "export.ps1"
        if (Test-Path $exportScript) {
            Write-Host "Sourcing ESP-IDF from $path"
            . $exportScript
            break
        }
    }
}

if (-not $env:IDF_PATH) {
    Write-Error @"
ESP-IDF environment not found.

Either:
  1. Open an 'ESP-IDF PowerShell' or 'ESP-IDF CMD' terminal, then run this script again, or
  2. Install ESP-IDF: https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/get-started/windows-setup.html
  3. Run: . C:\path\to\esp-idf\export.ps1
"@
}

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

Write-Host "Setting target esp32s3..."
idf.py set-target esp32s3

Write-Host "Building..."
idf.py build

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "Build succeeded. Flash with:"
    Write-Host "  .\scripts\flash-monitor.ps1 -Port COMx"
    Write-Host "  idf.py -p COMx flash monitor"
}

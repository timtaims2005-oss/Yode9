<!-- GENERATED FILE: do not edit directly -->
<!--lint disable remark-lint:awesome-badge-->

<h3 align="center">Pick Your Style:</h3>
<p align="center">
<a href="../"><img src="../assets/badge-style-awesome.svg" alt="Awesome" height="28"></a>
<a href="README_EXTRA.md"><img src="../assets/badge-style-extra.svg" alt="Extra" height="28"></a>
<a href="README_CLASSIC.md"><img src="../assets/badge-style-classic.svg" alt="Classic" height="28"></a>
<a href="README_FLAT_ALL_AZ.md"><img src="../assets/badge-style-flat.svg" alt="Flat" height="28" style="border: 2px solid #71717a; border-radius: 4px;"></a>
</p>

# Awesome Claude Code (Flat)

[![Awesome](https://awesome.re/badge-flat2.svg)](https://awesome.re)

A flat list view of all resources. Category: **Status** | Sorted: by last updated date

---

## Sort By:

<p align="center">
  <a href="README_FLAT_STATUSLINE_AZ.md"><img src="../assets/badge-sort-az.svg" alt="A - Z" height="48"></a>
  <a href="README_FLAT_STATUSLINE_UPDATED.md"><img src="../assets/badge-sort-updated.svg" alt="UPDATED" height="48" style="border: 3px solid #f472b6; border-radius: 6px;"></a>
  <a href="README_FLAT_STATUSLINE_CREATED.md"><img src="../assets/badge-sort-created.svg" alt="CREATED" height="48"></a>
  <a href="README_FLAT_STATUSLINE_RELEASES.md"><img src="../assets/badge-sort-releases.svg" alt="RELEASES" height="48"></a>
</p>
<p align="center"><strong>Category:</strong></p>
<p align="center">
  <a href="README_FLAT_ALL_UPDATED.md"><img src="../assets/badge-cat-all.svg" alt="All" height="28"></a>
  <a href="README_FLAT_TOOLING_UPDATED.md"><img src="../assets/badge-cat-tooling.svg" alt="Tooling" height="28"></a>
  <a href="README_FLAT_COMMANDS_UPDATED.md"><img src="../assets/badge-cat-commands.svg" alt="Commands" height="28"></a>
  <a href="README_FLAT_CLAUDE-MD_UPDATED.md"><img src="../assets/badge-cat-claude-md.svg" alt="CLAUDE.md" height="28"></a>
  <a href="README_FLAT_WORKFLOWS_UPDATED.md"><img src="../assets/badge-cat-workflows.svg" alt="Workflows" height="28"></a>
  <a href="README_FLAT_HOOKS_UPDATED.md"><img src="../assets/badge-cat-hooks.svg" alt="Hooks" height="28"></a>
  <a href="README_FLAT_SKILLS_UPDATED.md"><img src="../assets/badge-cat-skills.svg" alt="Skills" height="28"></a>
  <a href="README_FLAT_STYLES_UPDATED.md"><img src="../assets/badge-cat-styles.svg" alt="Styles" height="28"></a>
  <a href="README_FLAT_STATUSLINE_UPDATED.md"><img src="../assets/badge-cat-statusline.svg" alt="Status" height="28" style="border: 2px solid #84cc16; border-radius: 4px;"></a>
  <a href="README_FLAT_DOCS_UPDATED.md"><img src="../assets/badge-cat-docs.svg" alt="Docs" height="28"></a>
  <a href="README_FLAT_CLIENTS_UPDATED.md"><img src="../assets/badge-cat-clients.svg" alt="Clients" height="28"></a>
</p>
<p align="center"><em>Currently viewing: **Status** sorted by last updated date</em></p>

---

## Resources

<table>
<thead>
<tr>
<th>Resource</th>
<th>Category</th>
<th>Sub-Category</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://github.com/jarrodwatts/claude-hud"><b>Claude HUD</b></a><br>by <a href="https://github.com/jarrodwatts">Jarrod Watts</a></td>
<td>Status Lines</td>
<td>General</td>
<td>A really stacked status line that exposes just about everything you might need - context usage, tools, agents, todos, etc. Highly configurable and actively maintained at the time of writing - code quality is strong.</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/jarrodwatts/claude-hud?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/jarrodwatts/claude-hud?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/jarrodwatts/claude-hud?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/jarrodwatts/claude-hud?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/jarrodwatts/claude-hud?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/jarrodwatts/claude-hud?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/jarrodwatts/claude-hud?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/jarrodwatts/claude-hud?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/jarrodwatts/claude-hud?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/Astro-Han/claude-pace"><b>claude-pace</b></a><br>by <a href="https://github.com/Astro-Han">Astro-Han</a></td>
<td>Status Lines</td>
<td>General</td>
<td>A lightweight Bash + jq statusline for Claude Code that displays rate limit pace delta (burn rate vs. time remaining), 5h/7d usage percentage, context window usage, git branch and diff stats. Compares current consumption rate against time remaining in each rate limit window to indicate whether quota is being used faster or slower than the window allows. Single file with no external dependencies beyond jq.</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/Astro-Han/claude-pace?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/Astro-Han/claude-pace?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/Astro-Han/claude-pace?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/Astro-Han/claude-pace?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/Astro-Han/claude-pace?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/Astro-Han/claude-pace?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/Astro-Han/claude-pace?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/Astro-Han/claude-pace?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/Astro-Han/claude-pace?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/rz1989s/claude-code-statusline"><b>claude-code-statusline</b></a><br>by <a href="https://github.com/rz1989s">rz1989s</a></td>
<td>Status Lines</td>
<td>General</td>
<td>Enhanced 4-line statusline for Claude Code with themes, cost tracking, and MCP server monitoring</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/rz1989s/claude-code-statusline?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/rz1989s/claude-code-statusline?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/rz1989s/claude-code-statusline?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/rz1989s/claude-code-statusline?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/rz1989s/claude-code-statusline?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/rz1989s/claude-code-statusline?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/rz1989s/claude-code-statusline?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/rz1989s/claude-code-statusline?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/rz1989s/claude-code-statusline?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/sirmalloc/ccstatusline"><b>ccstatusline</b></a><br>by <a href="https://github.com/sirmalloc">sirmalloc</a></td>
<td>Status Lines</td>
<td>General</td>
<td>A highly customizable status line formatter for Claude Code CLI that displays model info, git branch, token usage, and other metrics in your terminal.</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/sirmalloc/ccstatusline?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/sirmalloc/ccstatusline?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/sirmalloc/ccstatusline?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/sirmalloc/ccstatusline?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/sirmalloc/ccstatusline?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/sirmalloc/ccstatusline?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/sirmalloc/ccstatusline?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/sirmalloc/ccstatusline?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/sirmalloc/ccstatusline?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/Owloops/claude-powerline"><b>claude-powerline</b></a><br>by <a href="https://github.com/Owloops">Owloops</a></td>
<td>Status Lines</td>
<td>General</td>
<td>A vim-style powerline statusline for Claude Code with real-time usage tracking, git integration, custom themes, and more</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/Owloops/claude-powerline?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/Owloops/claude-powerline?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/Owloops/claude-powerline?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/Owloops/claude-powerline?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/Owloops/claude-powerline?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/Owloops/claude-powerline?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/Owloops/claude-powerline?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/Owloops/claude-powerline?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/Owloops/claude-powerline?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/Haleclipse/CCometixLine"><b>CCometixLine - Claude Code Statusline</b></a><br>by <a href="https://github.com/Haleclipse">Haleclipse</a></td>
<td>Status Lines</td>
<td>General</td>
<td>A high-performance Claude Code statusline tool written in Rust with Git integration, usage tracking, interactive TUI configuration, and Claude Code enhancement utilities.</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/Haleclipse/CCometixLine?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/Haleclipse/CCometixLine?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/Haleclipse/CCometixLine?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/Haleclipse/CCometixLine?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/Haleclipse/CCometixLine?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/Haleclipse/CCometixLine?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/Haleclipse/CCometixLine?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/Haleclipse/CCometixLine?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/Haleclipse/CCometixLine?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/hagan/claudia-statusline"><b>claudia-statusline</b></a><br>by <a href="https://github.com/hagan">Hagan Franks</a></td>
<td>Status Lines</td>
<td>General</td>
<td>High-performance Rust-based statusline for Claude Code with persistent stats tracking, progress bars, and optional cloud sync. Features SQLite-first persistence, git integration, context progress bars, burn rate calculation, XDG-compliant with theme support (dark/light, NO_COLOR).</td>
</tr>
<tr>
<td colspan="4"><img src="https://img.shields.io/github/stars/hagan/claudia-statusline?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/hagan/claudia-statusline?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/hagan/claudia-statusline?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/hagan/claudia-statusline?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/hagan/claudia-statusline?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/hagan/claudia-statusline?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/hagan/claudia-statusline?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/hagan/claudia-statusline?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/hagan/claudia-statusline?style=flat-square" alt="license"></td>
</tr>
</tbody>
</table>

---

**Total Resources:** 7

**Last Generated:** 2026-04-21

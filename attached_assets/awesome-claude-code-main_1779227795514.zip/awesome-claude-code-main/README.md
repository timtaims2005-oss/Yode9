# Awesome Claude Code

<em>A delightfully curated collection of the finest of resources for the most excellent of agents, Claude Code, by Anthropic PBC. Contains high quality skills, agents, hooks, status lines, orchestrators, developer tooling, and all the latest features that the Claude Code team continue to ship. Suitable for beginners and veterans, with an emphasis on code quality, security, and originality.</em>

<br>

> [!NOTE]
> The old ways have come and gone. It's time to embrace the next phase.
> The previous Table of Contents was no longer fit for purpose, so a new organizational system is being prepared. Thanks to everyone who has contributed to and supported this repo, be ye human or machine.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/update-in-progress-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="assets/update-in-progress-light-2.svg">
  <img alt="Update in progress" src="assets/update-in-progress-light-2.svg">
</picture>

<br>

# Table of Contents

I. TODO

hm.

Him: Claude have you got any ideas?

Claude: Just hit me up on Telegram, I'll sort it out.

Him: I don't have Telegram...

Claude: ... This does not bode well.

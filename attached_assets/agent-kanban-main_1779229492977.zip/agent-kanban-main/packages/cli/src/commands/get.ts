import type { Command } from "commander";
import { createClient } from "../agent/leader.js";
import {
  formatAgent,
  formatAgentList,
  formatBoard,
  formatBoardList,
  formatLabelList,
  formatModelList,
  formatRepository,
  formatRepositoryList,
  formatSubagent,
  formatSubagentList,
  formatTask,
  formatTaskList,
  formatTaskListWide,
  formatTaskNotes,
  getOutputFormat,
  output,
} from "../output.js";
import { getProvider, normalizeRuntime } from "../providers/registry.js";

type AgentRef = {
  id: string;
  username: string;
  version: string;
  name: string;
  kind?: string;
  role?: string | null;
  runtime?: string;
  runtime_available?: boolean;
  created_at?: string;
};

function sortAgentVersions(agents: AgentRef[]): AgentRef[] {
  return [...agents].sort((a, b) => {
    if (a.version === "latest") return -1;
    if (b.version === "latest") return 1;
    return (b.created_at ?? "").localeCompare(a.created_at ?? "") || a.version.localeCompare(b.version);
  });
}

function formatAgentVersions(data: { username: string; versions: AgentRef[] }): string {
  if (data.versions.length === 0) return `No versions found for ${data.username}.`;
  const lines = [`${data.username}`];
  for (const agent of sortAgentVersions(data.versions)) {
    const version = agent.version.padEnd(8);
    const created = agent.created_at ? new Date(agent.created_at).toISOString().slice(0, 10) : "";
    lines.push(`  ${version} ${agent.id}  ${created}  ${agent.name}`);
  }
  return lines.join("\n");
}

function isNotFound(error: unknown): boolean {
  return typeof error === "object" && error !== null && "status" in error && error.status === 404;
}

async function getAgentOrVersions(client: any, id: string): Promise<{ value: any; formatter: (value: any) => string }> {
  try {
    return { value: await client.getAgent(id), formatter: formatAgent };
  } catch (error) {
    if (!isNotFound(error)) throw error;
  }

  const agents = (await client.listAgents()) as AgentRef[];
  const versions = sortAgentVersions(agents.filter((agent) => agent.username === id));
  if (versions.length === 0) {
    console.error(`Agent not found: ${id}`);
    process.exit(1);
  }
  return { value: { username: id, versions }, formatter: formatAgentVersions };
}

export function registerGetCommand(program: Command) {
  const getCmd = program.command("get").description("Get a resource or list resources");

  getCmd
    .command("board [id]")
    .description("Get a board or list boards")
    .option("-o, --output <format>", "Output format (json, yaml, text)")
    .action(async (id: string | undefined, opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      if (id) {
        const board = await client.getBoard(id);
        output(board, fmt, formatBoard, { kind: "board" });
      } else {
        const boards = await client.listBoards();
        output(boards, fmt, formatBoardList, { kind: "board" });
      }
    });

  getCmd
    .command("label")
    .description("List board labels")
    .requiredOption("--board <id>", "Board ID")
    .option("-o, --output <format>", "Output format (json, yaml, text)")
    .action(async (opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      const board = await client.getBoard(opts.board);
      output(board.labels ?? [], fmt, formatLabelList, { kind: "label" });
    });

  getCmd
    .command("task [id]")
    .description("Get a task or list tasks")
    .option("-o, --output <format>", "Output format (json, yaml, wide, text)")
    .option("--board <id>", "Board ID (required when listing)")
    .option("--status <status>", "Filter by status")
    .option("--label <label>", "Filter by label")
    .option("--repo <id>", "Filter by repository ID")
    .action(async (id: string | undefined, opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      if (id) {
        const task = await client.getTask(id);
        output(task, fmt, formatTask, { kind: "task" });
      } else {
        if (!opts.board) {
          console.error("Error: --board is required when listing tasks\nUsage: ak get task --board <id>");
          process.exit(1);
        }
        const params: Record<string, string> = { board_id: opts.board };
        if (opts.status) params.status = opts.status;
        if (opts.label) params.label = opts.label;
        if (opts.repo) params.repository_id = opts.repo;
        const tasks = await client.listTasks(params);
        output(tasks, fmt, formatTaskList, { wideFormatter: formatTaskListWide, kind: "task" });
      }
    });

  getCmd
    .command("agent [id]")
    .description("Get an agent or list agents")
    .option("-o, --output <format>", "Output format (json, yaml, text)")
    .option("--role <role>", "Filter by agent role")
    .option("--runtime <runtime>", "Filter by runtime")
    .option("--available", "Only show agents whose runtime is available")
    .action(async (id: string | undefined, opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      if (id) {
        const { value, formatter } = await getAgentOrVersions(client, id);
        output(value, fmt, formatter, { kind: "agent" });
      } else {
        const params: Record<string, string> = { kind: "worker" };
        if (opts.role) params.role = opts.role;
        if (opts.runtime) params.runtime = opts.runtime;
        if (opts.available) params.available = "true";
        const agents = (await client.listAgents(params)) as AgentRef[];
        output(agents, fmt, formatAgentList, { kind: "agent" });
      }
    });

  getCmd
    .command("subagent [id]")
    .description("Get a task-local subagent or list subagents")
    .option("-o, --output <format>", "Output format (json, yaml, text)")
    .action(async (id: string | undefined, opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      if (id) {
        const subagent = await client.getSubagent(id);
        output(subagent, fmt, formatSubagent, { kind: "subagent" });
      } else {
        const subagents = await client.listSubagents();
        output(subagents, fmt, formatSubagentList, { kind: "subagent" });
      }
    });

  getCmd
    .command("model")
    .description("List available models for a runtime")
    .requiredOption("--runtime <runtime>", "Runtime name")
    .option("-o, --output <format>", "Output format (json, yaml, text)")
    .action(async (opts) => {
      const fmt = getOutputFormat(opts.output);
      const provider = getProvider(normalizeRuntime(opts.runtime));
      if (!provider.listModels) {
        console.error(`Model listing is not supported by ${provider.label}.`);
        process.exit(1);
      }
      const models = await provider.listModels();
      output(models, fmt, formatModelList, { kind: "model" });
    });

  getCmd
    .command("repo [id]")
    .description("Get a repository or list repositories")
    .option("-o, --output <format>", "Output format (json, yaml, text)")
    .action(async (id: string | undefined, opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      if (id) {
        const repo = await client.getRepository(id);
        output(repo, fmt, formatRepository, { kind: "repo" });
      } else {
        const repos = await client.listRepositories();
        output(repos, fmt, formatRepositoryList, { kind: "repo" });
      }
    });

  getCmd
    .command("note [task-id]")
    .description("Get notes for a task")
    .option("-o, --output <format>", "Output format (json, text)")
    .option("--task <id>", "Task ID")
    .option("--since <timestamp>", "Only show notes after this timestamp")
    .action(async (taskId: string | undefined, opts) => {
      const client = await createClient();
      const fmt = getOutputFormat(opts.output);
      const id = taskId ?? opts.task;
      if (!id) {
        console.error("Usage: ak get note <task-id>  or  ak get note --task <task-id>");
        process.exit(1);
      }
      const notes = await client.getTaskNotes(id, opts.since);
      output(notes, fmt, formatTaskNotes);
    });
}
